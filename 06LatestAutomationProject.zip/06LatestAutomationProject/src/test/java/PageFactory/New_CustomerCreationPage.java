package PageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class New_CustomerCreationPage {
	
    WebDriver driver;
	
	public New_CustomerCreationPage(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath="//a[text()='New Customer']")
	WebElement newCustomer;
	
	@FindBy(xpath="//input[@name='name']")
	WebElement customerName;
	
	@FindBy(xpath="//input[@value='m']")
	WebElement gender;
	
	@FindBy(xpath="//textarea[@name='addr']")
	WebElement Address;
	
	@FindBy(xpath="//input[@id='dob']")
	WebElement DOB;
	
	
	
	public void clickonNewCustomerLink()
	{
		newCustomer.click();
	}
	
	public void enterCustomerName(String name)
	{
		customerName.sendKeys(name);
	}
	
	public void selectGender()

	{
		gender.click();
	}
	
	
	public void enterAddress(String address)
	{
		Address.sendKeys(address);
	}
	
	public void enterDateOfBirth(String dob)
	{
		DOB.sendKeys(dob);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
