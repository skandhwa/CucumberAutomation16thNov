package Constants;

public class Constants_New {

	public static final String TEST_DATA_PATH="D:\\TestData09thNovember.xlsx";
	public static final String PROPERTY_FILE_PATH="src\\main\\java\\PropertyData\\Global.properties";
	
}
